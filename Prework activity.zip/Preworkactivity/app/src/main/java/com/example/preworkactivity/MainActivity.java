package com.example.preworkactivity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.widget.Button;
import android.widget.EditText;
import android.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<String> items;

    Button btn_Add;
    EditText et_Item;
    RecyclerView rv_Items;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_Add = findViewById(R.id.btn_Add);
        et_Item = findViewById(R.id.et_Item);
        rv_Items = findViewById(R.id.rv_Items);

        et_Item.setText ("Im doing doinf this from Java");

        items = new ArrayList<>();
        items.add("Task 1");
        items.add("Task 2");
    }
}